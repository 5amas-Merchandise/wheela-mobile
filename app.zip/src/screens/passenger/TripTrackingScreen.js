// src/screens/passenger/TripTrackingScreen.js
import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Alert,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE, Polyline } from 'react-native-maps';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { getAuthToken, getStoredUser } from '../../utils/auth';
import { initSocket, onEvent, offEvent, emitEvent, disconnectSocket } from '../../utils/socket';

const { width, height } = Dimensions.get('window');
const ASPECT_RATIO = width / height;
const LATITUDE_DELTA = 0.015;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;
const baseUrl = 'https://wheels-backend.vercel.app';

export default function TripTrackingScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const mapRef = useRef(null);
  
  const {
    tripId,
    requestId,
    pickup,
    dropoff,
    pickupAddress,
    dropoffAddress,
    driverId,
    driverInfo: initialDriverInfo,
    estimatedFare,
    serviceType,
    distance,
    duration,
  } = route.params || {};

  const [tripStatus, setTripStatus] = useState('assigned');
  const [driverLocation, setDriverLocation] = useState(null);
  const [routeCoords, setRouteCoords] = useState([]);
  const [driverInfo, setDriverInfo] = useState(initialDriverInfo);
  const [loading, setLoading] = useState(true);
  const [timer, setTimer] = useState(0);
  const [timerInterval, setTimerInterval] = useState(null);
  const [pollingInterval, setPollingInterval] = useState(null);
  const [arrivalTime, setArrivalTime] = useState(null);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [tripDetails, setTripDetails] = useState(null);
  const [socketConnected, setSocketConnected] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(Date.now());

  useEffect(() => {
    const initializeTrip = async () => {
      try {
        setLoading(true);
        
        // Fetch trip details first
        await fetchTripDetails();
        
        // Initialize socket
        await initSocketAndListen();
        
        // Start timer
        const interval = setInterval(() => {
          setTimer(prev => prev + 1);
        }, 1000);
        setTimerInterval(interval);
        
        setLoading(false);
      } catch (error) {
        console.error('❌ Failed to initialize trip:', error);
        setLoading(false);
      }
    };

    initializeTrip();

    return () => {
      // Cleanup
      offEvent('trip:request_update');
      offEvent('trip:assigned');
      offEvent('trip:driver_update');
      offEvent('trip:driver_location');
      offEvent('trip:completed');
      offEvent('trip:cancelled');
      offEvent('notification');
      offEvent('connect');
      offEvent('disconnect');
      
      if (timerInterval) clearInterval(timerInterval);
      if (pollingInterval) clearInterval(pollingInterval);
      disconnectSocket();
    };
  }, []);

  const initSocketAndListen = async () => {
    try {
      const socket = await initSocket();
      
      if (socket) {
        setSocketConnected(true);
        setupSocketListeners();
        
        // Request trip status via socket
        if (requestId) {
          emitEvent('passenger:request_trip', { requestId });
        }
        
        // If we have tripId, listen for driver updates
        if (tripId) {
          emitEvent('passenger:request_status', { tripId });
        }
      } else {
        console.warn('⚠️ Socket initialization failed, using polling');
        startPollingForTripUpdates();
      }
    } catch (error) {
      console.error('❌ Socket init error:', error);
      startPollingForTripUpdates();
    }
  };

  const setupSocketListeners = () => {
    // Listen for trip request updates
    onEvent('trip:request_update', (data) => {
      console.log('📊 Trip request update:', data);
      if (data.requestId === requestId) {
        setTripStatus(data.status);
        setLastUpdate(Date.now());
      }
    });

    // Listen for trip assignment
    onEvent('trip:assigned', (data) => {
      console.log('🎯 Trip assigned:', data);
      if (data.requestId === requestId) {
        setTripStatus('assigned');
        fetchDriverInfo(data.driverId);
        setLastUpdate(Date.now());
      }
    });

    // Listen for driver location updates
    onEvent('trip:driver_location', (data) => {
      console.log('📍 Driver location update:', data);
      if (data.tripId === tripId) {
        setDriverLocation(data.driverLocation);
        updateArrivalTime(data.driverLocation);
        setLastUpdate(Date.now());
        
        if (mapRef.current && data.driverLocation) {
          mapRef.current.animateToRegion({
            latitude: data.driverLocation.latitude,
            longitude: data.driverLocation.longitude,
            latitudeDelta: LATITUDE_DELTA,
            longitudeDelta: LONGITUDE_DELTA,
          }, 1000);
        }
      }
    });

    // Listen for trip status updates
    onEvent('trip:driver_update', (data) => {
      console.log('🔄 Trip update:', data);
      if (data.tripId === tripId) {
        setTripStatus(data.status);
        setLastUpdate(Date.now());
        
        if (data.status === 'started') {
          Alert.alert('🚗 Trip Started', 'Your driver has started the trip!');
          fetchTripDetails();
        } else if (data.status === 'completed') {
          if (timerInterval) clearInterval(timerInterval);
          handleTripCompleted();
        }
      }
    });

    // Listen for trip cancellation
    onEvent('trip:cancelled', (data) => {
      if (data.tripId === tripId) {
        handleTripCancelled(data.reason);
      }
    });

    // Listen for notifications
    onEvent('notification', (data) => {
      console.log('📢 Notification:', data);
      if (data.data?.tripId === tripId || data.data?.requestId === requestId) {
        if (data.type === 'trip_started') {
          setTripStatus('started');
        } else if (data.type === 'trip_completed') {
          handleTripCompleted();
        } else if (data.type === 'trip_cancelled') {
          handleTripCancelled(data.body);
        }
      }
    });

    // Connection status listeners
    onEvent('connect', () => {
      console.log('✅ Socket connected in TripTrackingScreen');
      setSocketConnected(true);
      
      // Stop polling if socket reconnects
      if (pollingInterval) {
        clearInterval(pollingInterval);
        setPollingInterval(null);
      }
    });

    onEvent('disconnect', (reason) => {
      console.log('❌ Socket disconnected in TripTrackingScreen:', reason);
      setSocketConnected(false);
      
      // Start polling as fallback
      startPollingForTripUpdates();
    });
  };

  const startPollingForTripUpdates = () => {
    console.log('🔄 Starting polling for trip updates');
    
    // Clear any existing polling interval
    if (pollingInterval) clearInterval(pollingInterval);
    
    // Poll every 5 seconds for trip updates
    const pollInterval = setInterval(async () => {
      console.log('🔄 Polling for trip updates...');
      await fetchTripDetails();
      if (driverId) {
        await fetchDriverLocation();
      }
    }, 5000);
    
    setPollingInterval(pollInterval);
  };

  const fetchTripDetails = async () => {
    try {
      const token = await getAuthToken();
      if (!token) return;

      let url;
      if (tripId) {
        url = `${baseUrl}/trips/${tripId}`;
      } else if (requestId) {
        url = `${baseUrl}/trips/request/${requestId}`;
      } else {
        return;
      }

      const response = await fetch(url, {
        headers: { 
          Authorization: `Bearer ${token}`,
          'Cache-Control': 'no-cache'
        },
      });
      
      if (response.ok) {
        const data = await response.json();
        const tripData = data.trip || data;
        setTripDetails(tripData);
        setTripStatus(tripData.status);
        setLastUpdate(Date.now());
        
        // If trip is completed, handle it
        if (tripData.status === 'completed') {
          handleTripCompleted();
        }
      }
    } catch (error) {
      console.error('❌ Failed to fetch trip details:', error);
    }
  };

  const fetchDriverInfo = async (driverId) => {
    try {
      const token = await getAuthToken();
      const response = await fetch(`${baseUrl}/users/${driverId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      
      if (response.ok) {
        const data = await response.json();
        setDriverInfo(data);
      }
    } catch (error) {
      console.error('❌ Failed to fetch driver info:', error);
    }
  };

  const fetchDriverLocation = async () => {
    try {
      if (!driverId) return;
      
      const token = await getAuthToken();
      const response = await fetch(`${baseUrl}/drivers/${driverId}/location`, {
        headers: { 
          Authorization: `Bearer ${token}`,
          'Cache-Control': 'no-cache'
        },
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.location) {
          setDriverLocation({
            latitude: data.location.coordinates[1],
            longitude: data.location.coordinates[0],
          });
          updateArrivalTime({
            latitude: data.location.coordinates[1],
            longitude: data.location.coordinates[0],
          });
        }
      }
    } catch (error) {
      console.error('❌ Failed to fetch driver location:', error);
    }
  };

  const updateArrivalTime = (driverLoc) => {
    if (!driverLoc || !pickup) return;
    
    // Simple distance calculation
    const distanceToPickup = calculateDistance(driverLoc, pickup);
    const estimatedArrivalMinutes = Math.ceil((distanceToPickup / 40) * 60);
    
    const arrivalTime = new Date();
    arrivalTime.setMinutes(arrivalTime.getMinutes() + estimatedArrivalMinutes);
    setArrivalTime(arrivalTime);
  };

  const calculateDistance = (coord1, coord2) => {
    const R = 6371;
    const dLat = toRad(coord2.latitude - coord1.latitude);
    const dLon = toRad(coord2.longitude - coord1.longitude);
    const lat1 = toRad(coord1.latitude);
    const lat2 = toRad(coord2.latitude);

    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(lat1) * Math.cos(lat2); 
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    return R * c;
  };

  const toRad = (value) => {
    return value * Math.PI / 180;
  };

  const handleTripCompleted = () => {
    // Clean up intervals
    if (timerInterval) clearInterval(timerInterval);
    if (pollingInterval) clearInterval(pollingInterval);
    
    Alert.alert(
      '✅ Trip Completed!',
      'Thank you for riding with us. How was your trip?',
      [
        {
          text: 'Rate Driver',
          onPress: () => {
            navigation.replace('TripCompleted', {
              tripId,
              driverId,
              driverInfo,
              estimatedFare,
              serviceType,
            });
          },
        },
        {
          text: 'Later',
          style: 'cancel',
          onPress: () => {
            navigation.replace('TripCompleted', {
              tripId,
              driverId,
              driverInfo,
              estimatedFare,
              serviceType,
            });
          },
        },
      ]
    );
  };

  const handleTripCancelled = (reason) => {
    // Clean up intervals
    if (timerInterval) clearInterval(timerInterval);
    if (pollingInterval) clearInterval(pollingInterval);
    
    Alert.alert('❌ Trip Cancelled', reason || 'The trip was cancelled.', [
      {
        text: 'OK',
        onPress: () => navigation.navigate('PassengerMain'),
      },
    ]);
  };

  const callDriver = () => {
    if (driverInfo?.phone) {
      Alert.alert(
        '📞 Call Driver',
        `Call ${driverInfo.phone}?`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Call',
            onPress: () => {
              // In a real app: Linking.openURL(`tel:${driverInfo.phone}`);
              Alert.alert('Calling...', `Would call ${driverInfo.phone} in a real app`);
            },
          },
        ]
      );
    } else {
      Alert.alert('No Phone', 'Driver phone number not available');
    }
  };

  const cancelTrip = async () => {
    setShowCancelModal(true);
  };

  const confirmCancelTrip = async () => {
    try {
      const token = await getAuthToken();
      
      let url;
      if (tripId) {
        url = `${baseUrl}/trips/${tripId}/cancel`;
      } else if (requestId) {
        url = `${baseUrl}/trips/${requestId}/cancel`;
      } else {
        Alert.alert('Error', 'No trip or request ID found');
        return;
      }

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          reason: 'Cancelled by passenger',
        }),
      });
      
      if (response.ok) {
        setShowCancelModal(false);
        
        // Clean up
        if (timerInterval) clearInterval(timerInterval);
        if (pollingInterval) clearInterval(pollingInterval);
        disconnectSocket();
        
        navigation.navigate('PassengerMain');
      } else {
        throw new Error('Failed to cancel trip');
      }
    } catch (error) {
      console.error('❌ Cancel trip error:', error);
      Alert.alert('Error', 'Failed to cancel trip. Please try again.');
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatArrivalTime = (date) => {
    if (!date) return 'Calculating...';
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const formatLastUpdate = () => {
    const diff = Date.now() - lastUpdate;
    const seconds = Math.floor(diff / 1000);
    
    if (seconds < 60) return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    return `${Math.floor(seconds / 3600)}h ago`;
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#00B0F3" />
        <Text style={styles.loadingText}>Loading trip...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        provider={PROVIDER_GOOGLE}
        style={styles.map}
        initialRegion={{
          latitude: pickup?.latitude || 6.5244,
          longitude: pickup?.longitude || 3.3792,
          latitudeDelta: LATITUDE_DELTA,
          longitudeDelta: LONGITUDE_DELTA,
        }}
        showsUserLocation={true}
      >
        {/* Pickup Marker */}
        {pickup && (
          <Marker coordinate={pickup}>
            <View style={styles.pickupMarker}>
              <Ionicons name="location" size={24} color="white" />
            </View>
          </Marker>
        )}

        {/* Dropoff Marker */}
        {dropoff && (
          <Marker coordinate={dropoff}>
            <View style={styles.dropoffMarker}>
              <Ionicons name="flag" size={24} color="white" />
            </View>
          </Marker>
        )}

        {/* Driver Marker */}
        {driverLocation && (
          <Marker coordinate={driverLocation}>
            <View style={styles.driverMarker}>
              <Ionicons name="car" size={20} color="white" />
            </View>
          </Marker>
        )}

        {/* Route from driver to pickup */}
        {driverLocation && pickup && (
          <Polyline
            coordinates={[driverLocation, pickup]}
            strokeColor="#00B0F3"
            strokeWidth={3}
            lineDashPattern={[5, 5]}
          />
        )}

        {/* Route from pickup to dropoff */}
        {pickup && dropoff && (
          <Polyline
            coordinates={[pickup, dropoff]}
            strokeColor="#4ADE80"
            strokeWidth={4}
          />
        )}
      </MapView>

      {/* Status Bar */}
      <View style={styles.statusBar}>
        <View style={styles.statusContent}>
          <View style={[styles.statusIndicator, 
            { backgroundColor: 
              tripStatus === 'assigned' ? '#00B0F3' :
              tripStatus === 'started' ? '#4ADE80' :
              tripStatus === 'in_progress' ? '#4ADE80' :
              tripStatus === 'completed' ? '#4ADE80' : '#FF4444'
            }]} 
          />
          <View style={styles.statusTextContainer}>
            <Text style={styles.statusText}>
              {tripStatus === 'assigned' ? 'Driver on the way' :
               tripStatus === 'started' ? 'Trip in progress' :
               tripStatus === 'in_progress' ? 'On the way to destination' :
               tripStatus === 'completed' ? 'Trip completed' : 'Trip cancelled'}
            </Text>
            <View style={styles.statusSubRow}>
              <Text style={styles.timerText}>{formatTime(timer)}</Text>
              <View style={styles.connectionIndicator}>
                <View style={[styles.connectionDot, { backgroundColor: socketConnected ? '#4ADE80' : '#FFA500' }]} />
                <Text style={styles.connectionText}>{socketConnected ? 'Live' : 'Polling'}</Text>
              </View>
              <Text style={styles.updateText}>Updated {formatLastUpdate()}</Text>
            </View>
          </View>
        </View>
      </View>

      {/* Driver Info Card */}
      {driverInfo && (
        <View style={styles.driverCard}>
          <View style={styles.driverHeader}>
            <View style={styles.driverAvatar}>
              <Text style={styles.driverAvatarText}>
                {driverInfo.name?.charAt(0) || 'D'}
              </Text>
            </View>
            <View style={styles.driverDetails}>
              <Text style={styles.driverName}>{driverInfo.name || 'Driver'}</Text>
              <View style={styles.ratingRow}>
                <Ionicons name="star" size={16} color="#FFD700" />
                <Text style={styles.ratingText}>{driverInfo.rating || 4.8}</Text>
                <Text style={styles.plateText}>{driverInfo.vehiclePlate || 'ABC-123'}</Text>
              </View>
            </View>
            <TouchableOpacity style={styles.callButton} onPress={callDriver}>
              <Ionicons name="call" size={24} color="#00B0F3" />
            </TouchableOpacity>
          </View>
          
          {driverInfo.vehicleModel && (
            <View style={styles.vehicleInfo}>
              <Ionicons name="car" size={18} color="#666" />
              <Text style={styles.vehicleText}>
                {driverInfo.vehicleModel} • {driverInfo.vehicleColor || ''}
              </Text>
            </View>
          )}
          
          {arrivalTime && tripStatus === 'assigned' && (
            <View style={styles.arrivalInfo}>
              <Ionicons name="time" size={18} color="#00B0F3" />
              <Text style={styles.arrivalText}>
                Estimated arrival: {formatArrivalTime(arrivalTime)}
              </Text>
            </View>
          )}
        </View>
      )}

      {/* Trip Details */}
      <View style={styles.tripDetailsCard}>
        <View style={styles.tripDetailRow}>
          <Ionicons name="cash-outline" size={22} color="#666" />
          <View style={styles.tripDetailContent}>
            <Text style={styles.tripDetailLabel}>Fare</Text>
            <Text style={styles.tripDetailValue}>₦{estimatedFare?.toLocaleString() || '2,500'}</Text>
          </View>
        </View>
        
        <View style={styles.divider} />
        
        <View style={styles.tripDetailRow}>
          <Ionicons name="location-outline" size={22} color="#666" />
          <View style={styles.tripDetailContent}>
            <Text style={styles.tripDetailLabel}>Pickup</Text>
            <Text style={styles.tripDetailAddress} numberOfLines={2}>
              {pickupAddress || 'Current location'}
            </Text>
          </View>
        </View>
        
        <View style={styles.divider} />
        
        <View style={styles.tripDetailRow}>
          <Ionicons name="flag-outline" size={22} color="#666" />
          <View style={styles.tripDetailContent}>
            <Text style={styles.tripDetailLabel}>Dropoff</Text>
            <Text style={styles.tripDetailAddress} numberOfLines={2}>
              {dropoffAddress || 'Destination'}
            </Text>
          </View>
        </View>
      </View>

      {/* Cancel Button */}
      {tripStatus !== 'completed' && tripStatus !== 'cancelled' && (
        <TouchableOpacity style={styles.cancelTripButton} onPress={cancelTrip}>
          <Ionicons name="close-circle" size={24} color="#FF4444" />
          <Text style={styles.cancelTripText}>Cancel Trip</Text>
        </TouchableOpacity>
      )}

      {/* Cancel Confirmation Modal */}
      {showCancelModal && (
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Cancel Trip?</Text>
            <Text style={styles.modalText}>
              Are you sure you want to cancel this trip? A cancellation fee may apply.
            </Text>
            <View style={styles.modalButtons}>
              <TouchableOpacity 
                style={[styles.modalButton, styles.cancelModalButton]} 
                onPress={() => setShowCancelModal(false)}
              >
                <Text style={styles.cancelModalButtonText}>Go Back</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.modalButton, styles.confirmCancelButton]} 
                onPress={confirmCancelTrip}
              >
                <Text style={styles.confirmCancelButtonText}>Yes, Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  map: { flex: 1 },
  loadingContainer: { 
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center', 
    backgroundColor: '#F8F9FA' 
  },
  loadingText: { 
    marginTop: 16, 
    fontSize: 16, 
    color: '#666' 
  },
  statusBar: {
    position: 'absolute',
    top: 50,
    left: 16,
    right: 16,
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    elevation: 8,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  statusContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 12,
  },
  statusTextContainer: {
    flex: 1,
  },
  statusText: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  statusSubRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  timerText: {
    fontSize: 14,
    color: '#666',
    fontWeight: '500',
  },
  connectionIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  connectionDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginRight: 4,
  },
  connectionText: {
    fontSize: 12,
    color: '#666',
  },
  updateText: {
    fontSize: 12,
    color: '#999',
  },
  driverCard: {
    position: 'absolute',
    top: 130,
    left: 16,
    right: 16,
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    elevation: 8,
  },
  driverHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  driverAvatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#00B0F3',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  driverAvatarText: {
    color: 'white',
    fontSize: 20,
    fontWeight: '700',
  },
  driverDetails: {
    flex: 1,
  },
  driverName: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    marginLeft: 4,
    marginRight: 12,
    fontSize: 14,
    color: '#666',
  },
  plateText: {
    fontSize: 14,
    color: '#666',
    backgroundColor: '#F0F0F0',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
  },
  callButton: {
    padding: 8,
  },
  vehicleInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  vehicleText: {
    marginLeft: 8,
    fontSize: 14,
    color: '#666',
  },
  arrivalInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
  },
  arrivalText: {
    marginLeft: 8,
    fontSize: 14,
    color: '#00B0F3',
    fontWeight: '500',
  },
  tripDetailsCard: {
    position: 'absolute',
    bottom: 100,
    left: 16,
    right: 16,
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    elevation: 8,
  },
  tripDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tripDetailContent: {
    marginLeft: 12,
    flex: 1,
  },
  tripDetailLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 2,
  },
  tripDetailValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#000',
  },
  tripDetailAddress: {
    fontSize: 14,
    color: '#000',
    lineHeight: 18,
  },
  divider: {
    height: 1,
    backgroundColor: '#F0F0F0',
    marginVertical: 12,
  },
  cancelTripButton: {
    position: 'absolute',
    bottom: 30,
    left: 16,
    right: 16,
    backgroundColor: 'white',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 16,
    borderRadius: 12,
    elevation: 4,
  },
  cancelTripText: {
    marginLeft: 8,
    fontSize: 16,
    color: '#FF4444',
    fontWeight: '600',
  },
  modalOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 24,
    width: '100%',
    elevation: 12,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 12,
    textAlign: 'center',
  },
  modalText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 22,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  modalButton: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  cancelModalButton: {
    backgroundColor: '#F0F0F0',
    marginRight: 8,
  },
  cancelModalButtonText: {
    fontSize: 16,
    color: '#666',
    fontWeight: '600',
  },
  confirmCancelButton: {
    backgroundColor: '#FF4444',
    marginLeft: 8,
  },
  confirmCancelButtonText: {
    fontSize: 16,
    color: 'white',
    fontWeight: '600',
  },
  pickupMarker: {
    backgroundColor: '#00B0F3',
    padding: 12,
    borderRadius: 30,
    borderWidth: 3,
    borderColor: 'white',
  },
  dropoffMarker: {
    backgroundColor: '#FF4444',
    padding: 12,
    borderRadius: 30,
    borderWidth: 3,
    borderColor: 'white',
  },
  driverMarker: {
    backgroundColor: '#4ADE80',
    padding: 12,
    borderRadius: 30,
    borderWidth: 3,
    borderColor: 'white',
  },
});