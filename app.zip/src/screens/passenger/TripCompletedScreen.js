// src/screens/passenger/TripCompletedScreen.js
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  Image,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { Rating } from 'react-native-ratings'; // Changed import

export default function TripCompletedScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  
  const {
    tripId,
    driverId,
    driverInfo,
    estimatedFare,
    serviceType,
  } = route.params || {};

  const [rating, setRating] = useState(5);
  const [tipAmount, setTipAmount] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('wallet');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const tipOptions = [0, 100, 200, 500];

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    try {
      // Submit rating and complete payment
      // ... API calls here ...
      
      Alert.alert(
        'Trip Completed!',
        'Thank you for your feedback. Payment processed successfully.',
        [
          {
            text: 'OK',
            onPress: () => navigation.navigate('PassengerMain'),
          },
        ]
      );
    } catch (error) {
      Alert.alert('Error', 'Failed to submit rating. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatServiceType = (type) => {
    switch(type) {
      case 'CITY_RIDE': return 'City Ride';
      case 'DELIVERY_BIKE': return 'Bike';
      case 'LUXURY_RENTAL': return 'Luxury';
      case 'KEKE': return 'Keke';
      default: return type;
    }
  };

  const totalAmount = estimatedFare + tipAmount;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      {/* Success Header */}
      <View style={styles.successHeader}>
        <View style={styles.successIcon}>
          <Ionicons name="checkmark-circle" size={80} color="#4ADE80" />
        </View>
        <Text style={styles.successTitle}>Trip Completed!</Text>
        <Text style={styles.successSubtitle}>
          Thank you for riding with us
        </Text>
      </View>

      {/* Driver Info */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Your Driver</Text>
        <View style={styles.driverInfo}>
          <View style={styles.driverAvatar}>
            {driverInfo?.profilePhoto ? (
              <Image source={{ uri: driverInfo.profilePhoto }} style={styles.avatarImage} />
            ) : (
              <Text style={styles.driverAvatarText}>
                {driverInfo?.name?.charAt(0) || 'D'}
              </Text>
            )}
          </View>
          <View style={styles.driverDetails}>
            <Text style={styles.driverName}>{driverInfo?.name || 'Driver'}</Text>
            <Text style={styles.vehicleInfo}>
              {driverInfo?.vehicleModel || 'Car'} • {driverInfo?.vehiclePlate || 'ABC-123'}
            </Text>
          </View>
        </View>
      </View>

      {/* Rating */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Rate Your Driver</Text>
        <View style={styles.ratingContainer}>
          <Rating
            type='star'
            ratingCount={5}
            imageSize={40}
            startingValue={rating}
            onFinishRating={(value) => setRating(value)}
            style={styles.starContainer}
            tintColor="#FFFFFF"
            ratingColor="#FFD700"
            ratingBackgroundColor="#E0E0E0"
          />
          <Text style={styles.ratingText}>
            {rating === 5 ? 'Excellent!' : 
             rating === 4 ? 'Good' : 
             rating === 3 ? 'Average' : 
             rating === 2 ? 'Poor' : 'Very Poor'}
          </Text>
        </View>
      </View>

      {/* Tip */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Add a Tip (Optional)</Text>
        <View style={styles.tipContainer}>
          {tipOptions.map((tip) => (
            <TouchableOpacity
              key={tip}
              style={[
                styles.tipButton,
                tipAmount === tip && styles.selectedTipButton,
              ]}
              onPress={() => setTipAmount(tip)}
            >
              <Text style={[
                styles.tipButtonText,
                tipAmount === tip && styles.selectedTipButtonText,
              ]}>
                {tip === 0 ? 'No Tip' : `₦${tip}`}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Fare Breakdown */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Fare Breakdown</Text>
        <View style={styles.fareBreakdown}>
          <View style={styles.fareRow}>
            <Text style={styles.fareLabel}>Base Fare</Text>
            <Text style={styles.fareValue}>₦{estimatedFare?.toLocaleString()}</Text>
          </View>
          <View style={styles.fareRow}>
            <Text style={styles.fareLabel}>Tip</Text>
            <Text style={styles.fareValue}>₦{tipAmount.toLocaleString()}</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.fareRow}>
            <Text style={styles.totalLabel}>Total</Text>
            <Text style={styles.totalValue}>₦{totalAmount.toLocaleString()}</Text>
          </View>
        </View>
      </View>

      {/* Payment Method */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Payment Method</Text>
        <View style={styles.paymentMethods}>
          <TouchableOpacity
            style={[
              styles.paymentMethod,
              paymentMethod === 'wallet' && styles.selectedPaymentMethod,
            ]}
            onPress={() => setPaymentMethod('wallet')}
          >
            <Ionicons name="wallet" size={24} color={paymentMethod === 'wallet' ? '#00B0F3' : '#666'} />
            <Text style={[
              styles.paymentMethodText,
              paymentMethod === 'wallet' && styles.selectedPaymentMethodText,
            ]}>
              Wallet
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.paymentMethod,
              paymentMethod === 'cash' && styles.selectedPaymentMethod,
            ]}
            onPress={() => setPaymentMethod('cash')}
          >
            <Ionicons name="cash" size={24} color={paymentMethod === 'cash' ? '#00B0F3' : '#666'} />
            <Text style={[
              styles.paymentMethodText,
              paymentMethod === 'cash' && styles.selectedPaymentMethodText,
            ]}>
              Cash
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Submit Button */}
      <TouchableOpacity
        style={styles.submitButton}
        onPress={handleSubmit}
        disabled={isSubmitting}
      >
        {isSubmitting ? (
          <Text style={styles.submitButtonText}>Processing...</Text>
        ) : (
          <>
            <Text style={styles.submitButtonText}>Complete & Pay</Text>
            <Text style={styles.totalAmountText}>₦{totalAmount.toLocaleString()}</Text>
          </>
        )}
      </TouchableOpacity>

      {/* Back to Home */}
      <TouchableOpacity
        style={styles.homeButton}
        onPress={() => navigation.navigate('PassengerMain')}
      >
        <Text style={styles.homeButtonText}>Back to Home</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  contentContainer: {
    padding: 20,
    paddingBottom: 40,
  },
  successHeader: {
    alignItems: 'center',
    marginBottom: 30,
  },
  successIcon: {
    marginBottom: 16,
  },
  successTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#000',
    marginBottom: 8,
  },
  successSubtitle: {
    fontSize: 16,
    color: '#666',
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    elevation: 4,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#000',
    marginBottom: 16,
  },
  driverInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  driverAvatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#00B0F3',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  avatarImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  driverAvatarText: {
    color: 'white',
    fontSize: 20,
    fontWeight: '700',
  },
  driverDetails: {
    flex: 1,
  },
  driverName: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 4,
  },
  vehicleInfo: {
    fontSize: 14,
    color: '#666',
  },
  ratingContainer: {
    alignItems: 'center',
  },
  starContainer: {
    marginBottom: 12,
  },
  ratingText: {
    fontSize: 16,
    color: '#666',
    marginTop: 8,
  },
  tipContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  tipButton: {
    width: '48%',
    backgroundColor: '#F0F0F0',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 12,
  },
  selectedTipButton: {
    backgroundColor: '#00B0F3',
  },
  tipButtonText: {
    fontSize: 16,
    color: '#666',
    fontWeight: '600',
  },
  selectedTipButtonText: {
    color: 'white',
  },
  fareBreakdown: {
    padding: 4,
  },
  fareRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  fareLabel: {
    fontSize: 16,
    color: '#666',
  },
  fareValue: {
    fontSize: 16,
    color: '#000',
    fontWeight: '500',
  },
  divider: {
    height: 1,
    backgroundColor: '#F0F0F0',
    marginVertical: 8,
  },
  totalLabel: {
    fontSize: 18,
    color: '#000',
    fontWeight: '700',
  },
  totalValue: {
    fontSize: 24,
    color: '#000',
    fontWeight: '800',
  },
  paymentMethods: {
    flexDirection: 'row',
  },
  paymentMethod: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F0F0F0',
    paddingVertical: 16,
    borderRadius: 12,
    marginRight: 12,
  },
  selectedPaymentMethod: {
    backgroundColor: '#E6F7FF',
    borderWidth: 2,
    borderColor: '#00B0F3',
  },
  paymentMethodText: {
    marginLeft: 8,
    fontSize: 16,
    color: '#666',
    fontWeight: '600',
  },
  selectedPaymentMethodText: {
    color: '#00B0F3',
  },
  submitButton: {
    backgroundColor: '#00B0F3',
    paddingVertical: 20,
    borderRadius: 16,
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 16,
  },
  submitButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '700',
  },
  totalAmountText: {
    color: 'white',
    fontSize: 14,
    marginTop: 4,
  },
  homeButton: {
    alignItems: 'center',
    paddingVertical: 16,
  },
  homeButtonText: {
    color: '#00B0F3',
    fontSize: 16,
    fontWeight: '600',
  },
});