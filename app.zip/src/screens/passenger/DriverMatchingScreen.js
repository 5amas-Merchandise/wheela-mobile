// src/screens/passenger/DriverMatchingScreen.js
import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  Alert,
  Animated,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { getAuthToken, getStoredUser } from '../../utils/auth';
import { initSocket, onEvent, offEvent, emitEvent, disconnectSocket } from '../../utils/socket';

const { width, height } = Dimensions.get('window');
const baseUrl = 'https://wheels-backend.vercel.app';

export default function DriverMatchingScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const [isMatching, setIsMatching] = useState(true);
  const [matchProgress] = useState(new Animated.Value(0));
  const [timer, setTimer] = useState(0);
  const [timerInterval, setTimerInterval] = useState(null);
  const [requestId, setRequestId] = useState(null);
  const [assignedDriver, setAssignedDriver] = useState(null);
  const [error, setError] = useState(null);
  const [socketConnected, setSocketConnected] = useState(false);
  const [pollingInterval, setPollingInterval] = useState(null);
  const [userData, setUserData] = useState(null);

  const {
    pickup,
    dropoff,
    pickupAddress,
    dropoffAddress,
    serviceType,
    estimatedFare,
    distance,
    duration,
  } = route.params || {};

  useEffect(() => {
    // Load user data
    loadUserData();
    
    // Start matching animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(matchProgress, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }),
        Animated.timing(matchProgress, {
          toValue: 0,
          duration: 2000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Start timer
    const interval = setInterval(() => {
      setTimer((prev) => prev + 1);
    }, 1000);
    setTimerInterval(interval);

    // Create trip request
    createTripRequest();

    // Initialize socket for real-time updates
    initSocketAndListen();

    return () => {
      // Cleanup
      if (timerInterval) clearInterval(timerInterval);
      if (pollingInterval) clearInterval(pollingInterval);
      offEvent('trip:accepted');
      offEvent('notification');
      offEvent('trip:offered');
      offEvent('connect');
      offEvent('disconnect');
    };
  }, []);

  const loadUserData = async () => {
    try {
      const user = await getStoredUser();
      setUserData(user);
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };

  const initSocketAndListen = async () => {
    try {
      const socket = await initSocket();
      
      if (socket) {
        setSocketConnected(true);
        
        // Listen for trip acceptance
        onEvent('trip:accepted', (data) => {
          console.log('🎯 Trip accepted event received:', data);
          handleTripAccepted(data);
        });

        // Listen for notifications
        onEvent('notification', (data) => {
          console.log('📢 Notification received:', data);
          if (data.type === 'no_driver_found') {
            handleNoDriversFound(data);
          } else if (data.type === 'trip_accepted') {
            // If we get trip_accepted notification, handle it
            if (data.data?.requestId === requestId) {
              handleTripAccepted({
                requestId: data.data.requestId,
                driverId: data.data.driverId,
                tripId: data.data.tripId
              });
            }
          }
        });

        // Listen for trip offers (for debugging)
        onEvent('trip:offered', (data) => {
          console.log('🚗 Trip offered event:', data);
        });

        // Connection status listeners
        onEvent('connect', () => {
          console.log('✅ Socket connected in DriverMatchingScreen');
          setSocketConnected(true);
          
          // If we have a requestId, emit request status
          if (requestId) {
            emitEvent('passenger:request_trip', { requestId });
          }
        });

        onEvent('disconnect', (reason) => {
          console.log('❌ Socket disconnected in DriverMatchingScreen:', reason);
          setSocketConnected(false);
          
          // Start polling as fallback
          if (requestId) {
            startPollingForUpdates();
          }
        });

      } else {
        console.warn('⚠️ Socket initialization failed, using polling fallback');
        // Fallback to polling if socket fails
        if (requestId) {
          startPollingForUpdates();
        }
      }
    } catch (error) {
      console.error('❌ Failed to initialize socket:', error);
      // Fallback to polling
      if (requestId) {
        startPollingForUpdates();
      }
    }
  };

  const startPollingForUpdates = () => {
    console.log('🔄 Starting polling fallback for trip updates');
    // Clear any existing polling interval
    if (pollingInterval) clearInterval(pollingInterval);
    
    // Poll every 3 seconds for trip status
    const pollInterval = setInterval(async () => {
      if (requestId) {
        await checkTripStatus();
      }
    }, 7000);

    setPollingInterval(pollInterval);
  };

  const checkTripStatus = async () => {
    try {
      const token = await getAuthToken();
      if (!token) {
        console.error('❌ No token for polling');
        return;
      }

      console.log(`🔄 Polling trip status for request: ${requestId}`);
      
      const response = await fetch(`${baseUrl}/trips/request/${requestId}`, {
        headers: { 
          Authorization: `Bearer ${token}`,
          'Cache-Control': 'no-cache'
        },
      });
      
      // Check if response is JSON
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        console.error('❌ Server returned non-JSON response');
        return;
      }
      
      if (response.ok) {
        const data = await response.json();
        console.log('📊 Polled trip status:', data.trip?.status);
        
        if (data.trip?.status === 'assigned' && data.trip.assignedDriverId) {
          handleTripAccepted({
            requestId: requestId,
            driverId: data.trip.assignedDriverId,
            tripId: data.trip._id
          });
          
          // Stop polling once trip is assigned
          if (pollingInterval) {
            clearInterval(pollingInterval);
            setPollingInterval(null);
          }
        } else if (data.trip?.status === 'no_drivers') {
          handleNoDriversFound();
          
          // Stop polling
          if (pollingInterval) {
            clearInterval(pollingInterval);
            setPollingInterval(null);
          }
        }
      }
    } catch (error) {
      console.error('❌ Polling error:', error);
    }
  };

  const createTripRequest = async () => {
    try {
      const token = await getAuthToken();
      
      if (!token) {
        Alert.alert('Session Expired', 'Please login again.');
        navigation.replace('Login');
        return;
      }

      const requestData = {
        pickup: {
          type: 'Point',
          coordinates: [pickup.longitude, pickup.latitude],
        },
        serviceType,
        paymentMethod: 'wallet',
      };

      console.log('📝 Creating trip request:', requestData);

      const response = await fetch(`${baseUrl}/trips/request`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(requestData),
      });

      // Check if response is JSON before parsing
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        const text = await response.text();
        console.error('❌ Server returned non-JSON response:', text.substring(0, 200));
        throw new Error('Server error. Please try again later.');
      }

      const result = await response.json();

      if (response.ok) {
        console.log('✅ Trip request created:', result);
        setRequestId(result.requestId);
        
        if (result.message === 'No drivers available') {
          handleNoDriversFound();
        } else {
          // Start polling immediately as backup
          startPollingForUpdates();
        }
      } else {
        throw new Error(result.error?.message || result.message || 'Failed to create trip request');
      }
    } catch (error) {
      console.error('❌ Create trip request error:', error);
      setError(error.message);
      Alert.alert('Error', error.message || 'Failed to request ride. Please try again.');
    }
  };

  const handleTripAccepted = async (data) => {
    try {
      setIsMatching(false);
      
      // Clear polling interval
      if (pollingInterval) {
        clearInterval(pollingInterval);
        setPollingInterval(null);
      }
      
      // Clear timer
      if (timerInterval) {
        clearInterval(timerInterval);
        setTimerInterval(null);
      }

      // Fetch driver details
      const token = await getAuthToken();
      const response = await fetch(`${baseUrl}/users/${data.driverId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const driverData = await response.json();
        setAssignedDriver({
          ...driverData,
          driverId: data.driverId,
        });

        // Navigate to TripTrackingScreen after a short delay
        setTimeout(() => {
          navigation.replace('TripTracking', {
            tripId: data.tripId,
            requestId: data.requestId || requestId,
            pickup,
            dropoff,
            pickupAddress,
            dropoffAddress,
            driverId: data.driverId,
            driverInfo: driverData,
            estimatedFare,
            serviceType,
            distance,
            duration,
          });
        }, 1500);
      } else {
        // If we can't fetch driver details, still navigate with basic info
        setTimeout(() => {
          navigation.replace('TripTracking', {
            tripId: data.tripId,
            requestId: data.requestId || requestId,
            pickup,
            dropoff,
            pickupAddress,
            dropoffAddress,
            driverId: data.driverId,
            estimatedFare,
            serviceType,
            distance,
            duration,
          });
        }, 1500);
      }
    } catch (error) {
      console.error('❌ Error fetching driver details:', error);
      // Navigate anyway with available data
      setTimeout(() => {
        navigation.replace('TripTracking', {
          tripId: data.tripId,
          requestId: data.requestId || requestId,
          pickup,
          dropoff,
          pickupAddress,
          dropoffAddress,
          driverId: data.driverId,
          estimatedFare,
          serviceType,
          distance,
          duration,
        });
      }, 1500);
    }
  };

  const handleNoDriversFound = (data = null) => {
    setIsMatching(false);
    setError('No drivers available at the moment. Please try again later.');
    
    // Clean up intervals
    if (pollingInterval) {
      clearInterval(pollingInterval);
      setPollingInterval(null);
    }
    
    if (timerInterval) {
      clearInterval(timerInterval);
      setTimerInterval(null);
    }
    
    // Auto navigate back after 3 seconds
    setTimeout(() => {
      navigation.goBack();
    }, 3000);
  };

  const cancelMatching = async () => {
    // Clean up intervals
    if (pollingInterval) {
      clearInterval(pollingInterval);
      setPollingInterval(null);
    }
    
    if (timerInterval) {
      clearInterval(timerInterval);
      setTimerInterval(null);
    }
    
    if (requestId) {
      try {
        const token = await getAuthToken();
        await fetch(`${baseUrl}/trips/${requestId}/cancel`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ reason: 'Cancelled by passenger' }),
        });
      } catch (error) {
        console.error('❌ Cancel error:', error);
      }
    }
    
    disconnectSocket();
    navigation.goBack();
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const circleScale = matchProgress.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 1.5],
  });

  const circleOpacity = matchProgress.interpolate({
    inputRange: [0, 1],
    outputRange: [0.7, 0],
  });

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={cancelMatching} style={styles.backButton}>
          <Ionicons name="close" size={28} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Finding your ride</Text>
        <Text style={styles.timerText}>{formatTime(timer)}</Text>
      </View>

      {/* Matching Animation */}
      <View style={styles.animationContainer}>
        <View style={styles.carContainer}>
          <Animated.View
            style={[
              styles.pulseCircle,
              {
                transform: [{ scale: circleScale }],
                opacity: circleOpacity,
              },
            ]}
          />
          <Ionicons name="car-sport" size={80} color="#00B0F3" />
        </View>

        <Text style={styles.matchingText}>
          {isMatching ? 'Searching for nearby drivers...' : 'Driver found!'}
        </Text>

        {isMatching ? (
          <Text style={styles.subText}>
            We're finding the best driver for you
          </Text>
        ) : assignedDriver ? (
          <View style={styles.driverFoundContainer}>
            <Text style={styles.driverFoundText}>
              {assignedDriver.name} is on the way!
            </Text>
            <View style={styles.vehicleInfo}>
              <Ionicons name="car" size={20} color="#666" />
              <Text style={styles.vehicleText}>
                {assignedDriver.vehicleModel || 'Car'} • {assignedDriver.vehicleColor || ''}
              </Text>
            </View>
          </View>
        ) : null}
        
        {/* Connection Status */}
        <View style={styles.connectionStatus}>
          <View style={[styles.statusDot, { backgroundColor: socketConnected ? '#4ADE80' : '#FFA500' }]} />
          <Text style={styles.connectionText}>
            {socketConnected ? 'Live updates' : 'Polling for updates'}
          </Text>
        </View>
      </View>

      {/* Trip Details */}
      <View style={styles.tripDetailsCard}>
        <View style={styles.routeInfo}>
          <View style={styles.routePoint}>
            <View style={styles.pickupDot} />
            <View style={styles.verticalLine} />
          </View>
          <View style={styles.routeAddresses}>
            <View style={styles.addressRow}>
              <Text style={styles.addressLabel}>Pickup</Text>
              <Text style={styles.addressText} numberOfLines={1}>
                {pickupAddress || 'Current location'}
              </Text>
            </View>
            <View style={styles.addressRow}>
              <Text style={styles.addressLabel}>Dropoff</Text>
              <Text style={styles.addressText} numberOfLines={1}>
                {dropoffAddress || 'Destination'}
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.divider} />

        <View style={styles.tripStats}>
          <View style={styles.statItem}>
            <Ionicons name="cash-outline" size={20} color="#666" />
            <Text style={styles.statValue}>₦{estimatedFare?.toLocaleString()}</Text>
            <Text style={styles.statLabel}>Fare</Text>
          </View>
          <View style={styles.statItem}>
            <Ionicons name="time-outline" size={20} color="#666" />
            <Text style={styles.statValue}>{distance?.toFixed(1)} km</Text>
            <Text style={styles.statLabel}>Distance</Text>
          </View>
          <View style={styles.statItem}>
            <Ionicons name="car-outline" size={20} color="#666" />
            <Text style={styles.statValue}>
              {serviceType === 'CITY_RIDE' ? 'City Ride' : 
               serviceType === 'DELIVERY_BIKE' ? 'Bike' : 
               serviceType === 'LUXURY_RENTAL' ? 'Luxury' : 'Keke'}
            </Text>
            <Text style={styles.statLabel}>Service</Text>
          </View>
        </View>
      </View>

      {/* Error Message */}
      {error && (
        <View style={styles.errorContainer}>
          <Ionicons name="warning" size={24} color="#FF4444" />
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}

      {/* Cancel Button */}
      {isMatching && (
        <View style={styles.cancelContainer}>
          <TouchableOpacity style={styles.cancelButton} onPress={cancelMatching}>
            <Text style={styles.cancelButtonText}>Cancel Request</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: 'white',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#000',
  },
  timerText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#00B0F3',
  },
  animationContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  carContainer: {
    width: 160,
    height: 160,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
  },
  pulseCircle: {
    position: 'absolute',
    width: 160,
    height: 160,
    borderRadius: 80,
    backgroundColor: '#00B0F3',
  },
  matchingText: {
    fontSize: 24,
    fontWeight: '700',
    color: '#000',
    textAlign: 'center',
    marginBottom: 8,
  },
  subText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
  driverFoundContainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  driverFoundText: {
    fontSize: 20,
    fontWeight: '600',
    color: '#4ADE80',
    marginBottom: 8,
  },
  vehicleInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  vehicleText: {
    marginLeft: 8,
    fontSize: 14,
    color: '#666',
  },
  connectionStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#F8F9FA',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  connectionText: {
    fontSize: 12,
    color: '#666',
  },
  tripDetailsCard: {
    backgroundColor: 'white',
    marginHorizontal: 20,
    marginBottom: 30,
    borderRadius: 20,
    padding: 20,
    elevation: 8,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
  },
  routeInfo: {
    flexDirection: 'row',
  },
  routePoint: {
    alignItems: 'center',
    marginRight: 16,
  },
  pickupDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#00B0F3',
  },
  verticalLine: {
    width: 2,
    height: 40,
    backgroundColor: '#E0E0E0',
    marginVertical: 4,
  },
  routeAddresses: {
    flex: 1,
  },
  addressRow: {
    marginBottom: 16,
  },
  addressLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  addressText: {
    fontSize: 16,
    color: '#000',
    fontWeight: '500',
  },
  divider: {
    height: 1,
    backgroundColor: '#F0F0F0',
    marginVertical: 16,
  },
  tripStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#000',
    marginTop: 8,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFE5E5',
    marginHorizontal: 20,
    padding: 16,
    borderRadius: 12,
    marginBottom: 20,
  },
  errorText: {
    marginLeft: 12,
    fontSize: 14,
    color: '#FF4444',
    flex: 1,
  },
  cancelContainer: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  cancelButton: {
    backgroundColor: 'white',
    borderWidth: 2,
    borderColor: '#FF4444',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#FF4444',
    fontSize: 16,
    fontWeight: '700',
  },
});