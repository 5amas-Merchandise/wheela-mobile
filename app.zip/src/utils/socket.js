// src/utils/socket.js - COMPLETE FIX
import { io } from 'socket.io-client';
import { getAuthToken } from './auth';

let socket = null;
let reconnectAttempts = 0;
let reconnectTimer = null;
const MAX_RECONNECT_ATTEMPTS = 5;
const BASE_URL = 'https://wheels-backend-7ydc.onrender.com'; // FIXED: Removed 'ç' typo

export const initSocket = async () => {
  // If socket exists and is connected, return it
  if (socket?.connected) {
    console.log('✅ Socket already connected');
    return socket;
  }

  // Clear any existing reconnect timers
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }

  try {
    // Get auth token
    const token = await getAuthToken();
    if (!token) {
      console.error('❌ No auth token available for Socket.IO');
      return null;
    }

    // Clean the token
    const cleanToken = token.trim();
    console.log('🔌 Initializing Socket.IO connection...');

    // Disconnect existing socket if any
    if (socket) {
      socket.removeAllListeners();
      socket.disconnect();
      socket = null;
    }

    // Connect to Socket.IO server
    socket = io(BASE_URL, {
      auth: {
        token: cleanToken
      },
      transports: ['websocket', 'polling'], // Try websocket first
      reconnection: true, // Enable auto-reconnection
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      timeout: 20000, // Increased timeout to 20 seconds
      forceNew: false, // Reuse connection if possible
      autoConnect: true,
      query: {
        platform: 'mobile',
        timestamp: Date.now()
      }
    });

    // Connection event handlers
    socket.on('connect', () => {
      console.log('✅ Socket.IO connected successfully. Socket ID:', socket.id);
      reconnectAttempts = 0; // Reset reconnect attempts
      
      if (reconnectTimer) {
        clearTimeout(reconnectTimer);
        reconnectTimer = null;
      }
    });

    socket.on('disconnect', (reason) => {
      console.log('❌ Socket.IO disconnected. Reason:', reason);
      
      // Don't attempt reconnection if manually disconnected
      if (reason === 'io client disconnect') {
        console.log('🔌 Manual disconnect');
        return;
      }
    });

    socket.on('connect_error', (error) => {
      console.error('❌ Socket.IO connection error:', error.message);
    });

    socket.on('error', (error) => {
      console.error('❌ Socket.IO error:', error);
    });

    socket.on('connected', (data) => {
      console.log('📡 Server acknowledged connection:', data);
    });

    // Return the socket instance
    return socket;
  } catch (error) {
    console.error('❌ Failed to initialize socket:', error);
    return null;
  }
};

export const getSocket = () => {
  return socket;
};

export const disconnectSocket = () => {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }

  if (socket) {
    socket.removeAllListeners();
    socket.disconnect();
    socket = null;
    reconnectAttempts = 0;
    console.log('🔌 Socket disconnected and reset');
  }
};

export const emitEvent = (event, data) => {
  if (socket?.connected) {
    socket.emit(event, data);
    console.log(`📤 Emitted event: ${event}`, data);
  } else {
    console.warn(`⚠️ Socket not connected, cannot emit: ${event}`);
  }
};

export const onEvent = (event, callback) => {
  if (socket) {
    socket.on(event, callback);
    console.log(`📥 Listening to event: ${event}`);
  } else {
    console.warn(`⚠️ Socket not initialized, cannot listen to: ${event}`);
  }
};

export const offEvent = (event, callback) => {
  if (socket) {
    if (callback) {
      socket.off(event, callback);
    } else {
      socket.off(event);
    }
    console.log(`🔇 Stopped listening to event: ${event}`);
  }
};

export const isSocketConnected = () => {
  return socket?.connected || false;
};

export const getSocketId = () => {
  return socket?.id || null;
};

export const reconnectSocket = async () => {
  console.log('🔄 Manual reconnect requested...');
  reconnectAttempts = 0;
  disconnectSocket();
  return await initSocket();
};